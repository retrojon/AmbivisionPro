savedcmd_arch/arm/include/generated/calls-eabi.S := /bin/bash ./scripts/syscalltbl.sh --abis common,eabi arch/arm/tools/syscall.tbl arch/arm/include/generated/calls-eabi.S

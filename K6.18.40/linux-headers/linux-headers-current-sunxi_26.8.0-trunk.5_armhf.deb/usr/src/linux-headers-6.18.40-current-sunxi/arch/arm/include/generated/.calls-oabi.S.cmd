savedcmd_arch/arm/include/generated/calls-oabi.S := /bin/bash ./scripts/syscalltbl.sh --abis common,oabi arch/arm/tools/syscall.tbl arch/arm/include/generated/calls-oabi.S
